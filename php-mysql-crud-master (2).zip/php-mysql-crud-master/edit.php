<?php
include("db.php");
$title = '';
$description= '';

if  (isset($_GET['Matricula'])) {
  $Matricula = $_GET['Matricula'];
  $query = "SELECT * FROM escuela WHERE Matricula=$Matricula";
  $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_array($result);
    $Matricula = $row['Matricula'];
    $Nombres = $row['Nombres'];
    $Apellidos = $row['Apellidos'];
    $Semestral = $row['Semestral'];
  }
}

if (isset($_POST['update'])) {
  $Matricula = $_GET['Matricula'];
  $Nombres= $_POST['Nombres'];
  $Apellidos = $_POST['Apellidos'];
  $Semestral = $_POST['Semestral'];
  
  


  $query = "UPDATE escuela set Nombres = '$Nombres', Apellidos = '$Apellidos', Semestral = '$Semestral' WHERE Matricula=$Matricula";
  mysqli_query($conn, $query);
  $_SESSION['message'] = 'Task Updated Successfully';
  $_SESSION['message_type'] = 'warning';
  header('Location: index.php');
}

?>
<?php include('includes/header.php'); ?>
<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">
      <div class="card card-body">
      <form action="edit.php?Matricula=<?php echo $_GET['Matricula']; ?>" method="POST">
        <div class="form-group">
          <input name="Matricula" type="number" class="form-control" value="<?php echo $Matricula; ?>" placeholder="Matricula">
        </div>
          <div class="form-group">
            <input type="text" name="Nombres" class="form-control" value="<?php echo $Nombres; ?>"placeholder="Nombres" autofocus>
          </div>
          <div class="form-group">
            <input type="text" name="Apellidos" class="form-control" value="<?php echo $Apellidos; ?>"placeholder="Apellidos" autofocus>
          </div>
          <div class="form-group">
            <input type="text" name="Semestral" class="form-control" value="<?php echo $Semestral; ?>"placeholder="Semestral" autofocus>
          </div>
        
        <button class="btn-success" name="update">
          Update
</button>
      </form>
      </div>
    </div>
  </div>
</div>
<?php include('includes/footer.php'); ?>
