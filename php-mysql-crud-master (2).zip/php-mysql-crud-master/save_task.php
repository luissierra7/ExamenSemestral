<?php

include('db.php');

if (isset($_POST['save_task'])) {
  $Matricula = $_POST['Matricula'];
  $Nombres = $_POST['Nombres'];
  $Apellidos = $_POST['Apellidos'];
  $Semestral = $_POST['Semestral'];
  $query = "INSERT INTO Escuela(Matricula, Nombres, Apellidos, Semestral) VALUES ('$Matricula', '$Nombres', '$Apellidos', '$Semestral')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Saved Successfully';
  $_SESSION['message_type'] = 'success';
  header('Location: index.php');

}

?>
