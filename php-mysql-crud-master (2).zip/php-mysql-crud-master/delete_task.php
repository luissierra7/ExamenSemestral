<?php

include("db.php");

if(isset($_GET['Matricula'])) {
  $Matricula = $_GET['Matricula'];
  $query = "DELETE FROM escuela WHERE Matricula = $Matricula";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Removed Successfully';
  $_SESSION['message_type'] = 'danger';
  header('Location: index.php');
}

?>
