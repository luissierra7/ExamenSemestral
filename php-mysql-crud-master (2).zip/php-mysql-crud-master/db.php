<?php
session_start();

$conn = mysqli_connect(
  'localhost',
  'root',
  '',
  'bdd'
) or die(mysqli_erro($mysqli));

?>
